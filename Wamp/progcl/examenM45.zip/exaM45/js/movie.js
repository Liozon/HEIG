// Aide pour les URL des Web Services
var WS = "https://chabloz.eu/movies/";
var WS_THUMB = "https://chabloz.eu/movies/thumb/?id=";
var WS_RATING = "https://chabloz.eu/movies/rating/get/";
var WS_RATEIT = "https://chabloz.eu/movies/rating/post/";

// Aide: pour arrondir un nombre à l'entier le plus proche: Math.round(nb_ici);
