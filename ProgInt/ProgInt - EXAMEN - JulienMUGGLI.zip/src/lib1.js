export default function () {
    console.log("Je suis un test n°2");
}